
<nav id="sidebar" class="sidebar js-sidebar">
			<div class="sidebar-content js-simplebar">
				<a class="sidebar-brand" href="index.html">
          <span class="align-middle">AdvoWorld|ADVOCATE</span>
        </a>

				<ul class="sidebar-nav">
					

					<li class="sidebar-item active">
						<a class="sidebar-link" href="home.php">
              <i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span>
            </a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="profile.php">
              <i class="align-middle" data-feather="briefcase"></i> <span class="align-middle">Profile</span>
            </a>
					</li>
					
					<li class="sidebar-item">
						<a class="sidebar-link" href="pendingre.php">
              <i class="align-middle" data-feather="loader"></i> <span class="align-middle">Pending Requests</span>
            </a>
					</li>
				<li class="sidebar-item">
						<a class="sidebar-link" href="allreq.php">
              <i class="align-middle" data-feather="list"></i> <span class="align-middle">All Requests</span>
            </a>
					</li>
		<li class="sidebar-item">
						<a class="sidebar-link" href="addlawyer.php">
              <i class="align-middle" data-feather="user-plus"></i> <span class="align-middle">Add Laywers</span>
            </a>
					</li>
					
					<li class="sidebar-item">
						<a class="sidebar-link" href="feedback.php">
              <i class="align-middle" data-feather="edit"></i> <span class="align-middle">Feedback</span>
            </a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="logout.php">
              <i class="align-middle" data-feather="log-out"></i> <span class="align-middle">Logout</span>
            </a>
					</li>

					
				</ul>
			</div>
		</nav>