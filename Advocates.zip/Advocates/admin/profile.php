<?php
session_start();
if(!isset($_SESSION['lawyer']))
{
	echo "<script> location.href='index.php'; </script>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
	<meta name="author" content="AdminKit">
	<meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link rel="shortcut icon" href="img/icons/icon-48x48.png" />

	<link rel="canonical" href="https://demo-basic.adminkit.io/ui-forms.html" />

	<title>Forms | AdminKit Demo</title>

	<link href="css/app.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
</head>

<body>
	<div class="wrapper">
		<?php include('nav.php'); ?>

		<div class="main">
			<?php include('head.php'); ?>

			<main class="content">
				<div class="container-fluid p-0">
<?php
												include("config.php");
												$query2 = "select * from lawyer where email='".$_SESSION['lawyer']."'";
												$result1 = mysqli_query($con,$query2);
												$count1=mysqlI_num_rows($result1);

												if($count1>0)
												{
												$sl=0;
												while($row1 = mysqli_fetch_array($result1))
												{
												$cid=$row1[0];
												$name=$row1[1];
												$type=$row1[2];
												$phone=$row1[3];
												$email=$row1[4];
												$password=$row1[5];
												$image=$row1[6];
												$firm=$row1[7];
												$info=$row1[8];
												$personal=$row1[9];
												$family=$row1[10];
												$immigration=$row1[11];
												$criminal=$row1[12];
												$tax=$row1[13];
												$total=$row1[14];
												$success=$row1[15];
												$addr=$row1[16];
												$city=$row1[17];
												}
												}
												?>
					<div class="mb-3">
						<h1 class="h3 d-inline align-middle">Profile</h1>
						
					</div>
					<div class="row">
						<div class="col-12 col-lg-6">
							<div class="card">
								<div class="card-header">
									<h5 class="card-title mb-0">Update Profile</h5>
								</div>
								<div class="card-body">
								<form  method="POST" action="#"  enctype="multipart/form-data" >  
									<div class="mb-3">
										<label class="form-label">Profile image</label>
										<input type="file" class="form-control" name="image" placeholder="Profile image">
									</div>
									<div class="mb-3">
										<label class="form-label">Name</label>
										<input type="text" class="form-control" name="name" value="<?php echo $name; ?>" placeholder="Name">
									</div>
									<div class="mb-3">
										<label class="form-label">Phone</label>
										<input type="text" class="form-control" name="phone" value="<?php echo $phone; ?>" placeholder="Phone No">
									</div>
									<?php
									if($type=='Law Firm')
									{
									?>
									<div class="mb-3">
										<label class="form-label">Firm Name</label>
										<input type="text" class="form-control" name="firm" value="<?php echo $firm; ?>" placeholder="Firm Name">
									</div>
									<?php
									}
									?>
									<div class="mb-3">
										<label class="form-label">Detail Info</label>
										<textarea class="form-control" rows="2" name="info" placeholder="Detailed Info"><?php echo $info; ?></textarea>
									</div>
									<div class="mb-3">
										<input type="checkbox" class="form-check-input" name="personal" value="personal" <?php if($personal=='personal'){?>checked<?php } ?> >
										<label class="form-label">Personal Injury Lawyer</label>
									</div>
									<div class="mb-3">
										<input type="checkbox" class="form-check-input" name="family" value="family" <?php if($family=='family'){?>checked<?php } ?> >
										<label class="form-label">Family Lawyer</label>
									</div>
									<div class="mb-3">
										<input type="checkbox" class="form-check-input" name="immigration" value="immigration" <?php if($immigration=='immigration'){?>checked<?php } ?> >
										<label class="form-label">Immigration Lawyer</label>
									</div>
									<div class="mb-3">
										<input type="checkbox" class="form-check-input" name="criminal" value="criminal" <?php if($criminal=='criminal'){?>checked<?php } ?> >
										<label class="form-label">Criminal Defence Lawyer</label>
									</div>
									<div class="mb-3">
										<input type="checkbox" class="form-check-input" name="tax" value="tax" <?php if($tax=='tax'){?>checked<?php } ?> >
										<label class="form-label">Tax Lawyer</label>
									</div>
									<div class="mb-3">
										<label class="form-label">Total No of Cases Handled</label>
										<input type="text" class="form-control" name="total" value="<?php echo $total; ?>" placeholder="Total Cases">
									</div>
									<div class="mb-3">
										<label class="form-label">Success Rate</label>
										<input type="number" class="form-control" name="success" value="<?php echo $success; ?>" placeholder="Success Rate in %">
									</div>
									<div class="mb-3">
										<label class="form-label">Address</label>
										<input type="text" class="form-control" name="addr" value="<?php echo $addr; ?>" placeholder="Address">
									</div>
									<div class="mb-3">
										<label class="form-label">City</label>
										<input type="text" class="form-control" name="city" value="<?php echo $city; ?>" placeholder="Address">
									</div>
									<div class="mb-3">
										<input type="submit" class="btn btn-primary form-control" value="Update" name="update">
									</div>
									
								</div>
							</div>
						</div>
								</form>
					  
					  <?php
if(isset($_POST['update']))
{
	error_reporting(1);
	include("config.php");
	
	$name=$_POST['name'];
	$phone=$_POST['phone'];
	$firm=$_POST['firm'];
	$info=$_POST['info'];
	$personal=$_POST['personal'];
	$family=$_POST['family'];
	$immigration=$_POST['immigration'];
	$criminal=$_POST['criminal'];
	$tax=$_POST['tax'];
	$total=$_POST['total'];
	$success=$_POST['success'];
	$addr=$_POST['addr'];
	$city=$_POST['city'];

	
		$fname = $_FILES["image"]["name"];
		if($fname=='')
		{
			$query1= "update lawyer set name='".$name."',phone='".$phone."',firm='".$firm."',info='".$info."',personal='".$personal."',family='".$family."',immigration='".$immigration."',criminal='".$criminal."',tax='".$tax."',total='".$total."',success='".$success."',addr='".$addr."',city='".$city."' where email='".$_SESSION['lawyer']."'";
			   
			if(mysqli_query($con,$query1))
			{
				echo "<script>
					alert('Profile Updated successfully.');
					</script>";
				echo "<script> location.href='profile.php'; </script>";
			}
		}
		else
		{
		$filename = $firm.$fname;
		$tempname = $_FILES["image"]["tmp_name"];   
		$folder = "profile/".$filename;
		if (move_uploaded_file($tempname, $folder))  
		{
			$query1= "update lawyer set name='".$name."',phone='".$phone."',image='".$filename."',firm='".$firm."',info='".$info."',personal='".$personal."',family='".$family."',immigration='".$immigration."',criminal='".$criminal."',tax='".$tax."',total='".$total."',success='".$success."',addr='".$addr."',city='".$city."' where email='".$_SESSION['lawyer']."'";
			   
			if(mysqli_query($con,$query1))
			{
				echo "<script>
					alert('Profile Updated successfully.');
					</script>";
				echo "<script> location.href='profile.php'; </script>";
			}
		}
		else
		{
		echo "<script>
		alert('Select a valid image of lesser size');
		</script>";
		echo "<script> location.href='add criminal.php'; </script>";
		}
		}
		
}
?>

						<div class="col-md-6 col-xl-6">
							<div class="card mb-3">
								<div class="card-header">
									<h5 class="card-title mb-0">Profile Details</h5>
								</div>
								<div class="card-body text-center">
									<img src="profile/<?php echo $image; ?>" alt=" " class="img-fluid rounded-circle mb-2" width="128" height="128" />
									<h5 class="card-title mb-0">Firm: <?php echo $firm; ?></h5>
									<div class="text-muted mb-2"><?php echo $name; ?></div>

								</div>
								<hr class="my-0" />
								<div class="card-body">
									<h5 class="h6 card-title">Lawyer Type</h5>
									<?php if($personal=='personal'){?><a href="#" class="badge bg-primary me-1 my-1">Personal Injury Lawyer</a><br><?php } ?>
									<?php if($family=='family'){?><a href="#" class="badge bg-primary me-1 my-1">Family Lawyer</a><br><?php } ?>
									<?php if($immigration=='immigration'){?><a href="#" class="badge bg-primary me-1 my-1">Immigration Lawyer</a><br><?php } ?>
									<?php if($criminal=='criminal'){?><a href="#" class="badge bg-primary me-1 my-1">Criminal Defence Lawyer</a><br><?php } ?>
									<?php if($tax=='tax'){?><a href="#" class="badge bg-primary me-1 my-1">Tax Lawyer</a><br><?php } ?>
									
								</div>
								<hr class="my-0" />
								<div class="card-body">
									<h5 class="h6 card-title">About</h5>
									<ul class="list-unstyled mb-0">
										<li class="mb-1"><span data-feather="home" class="feather-sm me-1"></span> Address <a href="#"><?php echo $addr; ?></a></li>
										<li class="mb-1"><span data-feather="map-pin" class="feather-sm me-1"></span> City <a href="#"><?php echo $city; ?></a></li>

										<li class="mb-1"><span data-feather="phone" class="feather-sm me-1"></span> Phone <a href="#"><?php echo $phone; ?></a></li>
									</ul>
								</div>
								<hr class="my-0" />
								<div class="card-body">
									<h5 class="h6 card-title">Detailed Info</h5>
									<ul class="list-unstyled mb-0">
										<li class="mb-1"><a href=""><?php echo $info; ?></a></li>
										
									</ul>
								</div>
								<div class="card-body">
									<h5 class="h6 card-title">Experience</h5>
									<ul class="list-unstyled mb-0">
										<li class="mb-1"><span data-feather="briefcase" class="feather-sm me-1"></span> Total No Of Cases Undertaken <a href=""><?php echo $total; ?></a></li>
										<li class="mb-1"><span data-feather="briefcase" class="feather-sm me-1"></span> Success Rate <a href=""><?php echo $success; ?>%</a></li>
										
									</ul>
								</div>
							</div>
						</div>
					</div>

				</div>
			</main>

			<footer class="footer">
				<div class="container-fluid">
					<div class="row text-muted">
						<div class="col-6 text-start">
							<p class="mb-0">
								<a class="text-muted" href="https://adminkit.io/" target="_blank"><strong>AdminKit</strong></a> &copy;
							</p>
						</div>
						<div class="col-6 text-end">
							<ul class="list-inline">
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Support</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Help Center</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Privacy</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Terms</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</footer>
		</div>
	</div>

	<script src="js/app.js"></script>

</body>

</html>