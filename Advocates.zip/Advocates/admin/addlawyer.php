<?php
session_start();
if(!isset($_SESSION['lawyer']))
{
	echo "<script> location.href='index.php'; </script>";
}
include("config.php");
												$query2 = "select type from lawyer where email='".$_SESSION['lawyer']."'";
												$result1 = mysqli_query($con,$query2);
												$count1=mysqlI_num_rows($result1);

												if($count1>0)
												{
												while($row1 = mysqli_fetch_array($result1))
												{
												$utype=$row1[0];
												}
												}
if($utype!='Law Firm')
{
	echo "<script>
		alert('This Page is applicable only for Law Firms');
		</script>";
	echo "<script> location.href='home.php'; </script>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
	<meta name="author" content="AdminKit">
	<meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link rel="shortcut icon" href="img/icons/icon-48x48.png" />

	<link rel="canonical" href="https://demo-basic.adminkit.io/ui-forms.html" />

	<title>Forms | AdminKit Demo</title>

	<link href="css/app.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
</head>

<body>
	<div class="wrapper">
		<?php include('nav.php'); ?>

		<div class="main">
			<?php include('head.php'); ?>

			<main class="content">
				<div class="container-fluid p-0">

					<div class="mb-3">
						<h1 class="h3 d-inline align-middle">Add Lawyer</h1>
						
					</div>
					<div class="row">
						<div class="col-12 col-lg-12">
							<div class="card">
								<div class="card-header">
									<h5 class="card-title mb-0">Lawyer Info</h5>
								</div>
								<div class="card-body">
								<form  method="POST" action="#"  enctype="multipart/form-data" >  
									<div class="mb-3">
										<label class="form-label">Profile image</label>
										<input type="file" class="form-control" name="image" placeholder="Profile image" required>
									</div>
									<div class="mb-3">
										<label class="form-label">Name</label>
										<input type="text" class="form-control" name="name" placeholder="Name" required>
									</div>
									<div class="mb-3">
										<label class="form-label">Experience (Years)</label>
										<input type="number" class="form-control" name="experience" placeholder="Experience" required>
									</div>
									<div class="mb-3">
										<label class="form-label">No of Cases</label>
										<input type="number" class="form-control" name="cases" placeholder="No of Cases" required>
									</div>
									<div class="mb-3">
										<input type="submit" class="btn btn-primary form-control" value="Add" name="add">
									</div>
									
								</div>
							</div>
						</div>
								</form>
					  
					  <?php
if(isset($_POST['add']))
{
	error_reporting(1);
	include("config.php");
	
	$name=$_POST['name'];
	$experience=$_POST['experience'];
	$cases=$_POST['cases'];
	

		$fname = $_FILES["image"]["name"];
		$filename = $name.$fname;
		$tempname = $_FILES["image"]["tmp_name"];   
		$folder = "lawyers/".$filename;
		if (move_uploaded_file($tempname, $folder))  
		{
			$query1= "INSERT INTO `jrlawyer`(`name`, `cases`, `image`, `experience`, `lid`) VALUES ('".$name."','".$cases."','".$filename."','".$experience."','".$_SESSION['lawyer']."')";
			   
			if(mysqli_query($con,$query1))
			{
				echo "<script>
					alert('Lawyer Added successfully.');
					</script>";
				echo "<script> location.href='addlawyer.php'; </script>";
			}
		}
		else
		{
		echo "<script>
		alert('Select a valid image of lesser size');
		</script>";
		echo "<script> location.href='addlawyer.php'; </script>";
		}
		
}
?>
<?php
												include("config.php");
												$query2 = "select * from jrlawyer where lid='".$_SESSION['lawyer']."'";
												$result1 = mysqli_query($con,$query2);
												$count1=mysqlI_num_rows($result1);

												if($count1>0)
												{
												$sl=0;
												while($row1 = mysqli_fetch_array($result1))
												{
												$id=$row1[0];
												$name=$row1[1];
												$case=$row1[2];
												$image=$row1[3];
												$experience=$row1[4];
												?>
						<div class="col-md-3 col-xl-3">
							<div class="card mb-3">
								<div class="card-body text-center">
									<img src="lawyers/<?php echo $image; ?>" alt=" " class="img-fluid rounded-circle mb-2" width="128" height="128" />
									<h5 class="card-title mb-0"><?php echo $name; ?></h5>
									<div class="text-muted mb-2">Experience: <?php echo $experience; ?> years.</div>
									<div class="text-muted mb-2">No Of Cases:<?php echo $case; ?></div>

								</div>
								<hr class="my-0" />
								<div class="card-body text-center">
									<a href="addlawyer.php?delid=<?php echo $id; ?>"><button class="btn btn-danger">Delete</button></a>
									<a href="updatelawyer.php?id=<?php echo $id; ?>"><button class="btn btn-success">Update</button></a>

								</div>
							</div>
						</div>
						<?php
												}
												}
												if(isset($_GET['delid']))
												{
													$delid=$_GET['delid'];
													$query2 = "delete from jrlawyer where id='".$delid."'";
													if(mysqli_query($con,$query2))
													{
														echo "<script>
														alert('lawyer deleted');
														</script>";
														echo "<script> location.href='addlawyer.php'; </script>";
													}
													
												}
												?>
					</div>

				</div>
			</main>

			<footer class="footer">
				<div class="container-fluid">
					<div class="row text-muted">
						<div class="col-6 text-start">
							<p class="mb-0">
								<a class="text-muted" href="https://adminkit.io/" target="_blank"><strong>AdminKit</strong></a> &copy;
							</p>
						</div>
						<div class="col-6 text-end">
							<ul class="list-inline">
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Support</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Help Center</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Privacy</a>
								</li>
								<li class="list-inline-item">
									<a class="text-muted" href="https://adminkit.io/" target="_blank">Terms</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</footer>
		</div>
	</div>

	<script src="js/app.js"></script>

</body>

</html>