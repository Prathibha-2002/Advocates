<?php
session_start();
if(!isset($_SESSION['admin']))
{
	echo "<script> location.href='index.php'; </script>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
	<meta name="author" content="AdminKit">
	<meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link rel="shortcut icon" href="img/icons/icon-48x48.png" />

	<link rel="canonical" href="https://demo-basic.adminkit.io/ui-forms.html" />

	<title>Forms | Admin</title>

	<link href="css/app.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
</head>

<body>
	<div class="wrapper">
		<?php include('nav.php'); ?>

		<div class="main">
			<?php include('head.php'); ?>

			<main class="content">
				<div class="container-fluid p-0">

					<div class="mb-3">
						<h1 class="h3 d-inline align-middle">Feedback</h1>
						
					</div>
					<div class="row">
						<div class="col-12 col-lg-12 col-xxl-12 d-flex">
							<div class="card flex-fill">
								<div class="card-header">

									<h5 class="card-title mb-0">Feedback</h5>
								</div>
								<table class="table table-hover my-0">
									<thead>
										<tr>
											<th>Sl.No</th>
											<th>Name</th>
											<th>Email</th>
											<th class="d-none d-xl-table-cell">Feedback</th>
											<th class="d-none d-xl-table-cell">Type</th>
											<th class="d-none d-xl-table-cell">Delete</th>
										</tr>
									</thead>
									<tbody>
									<?php
											include("config.php");
											$query2 = "select * from feedback";
												$result1 = mysqli_query($con,$query2);
												$count1=mysqlI_num_rows($result1);

												if($count1>0)
												{
												$sl=0;
												while($row1 = mysqli_fetch_array($result1))
												{
												$sl+=1;
												$id=$row1[0];
												$name=$row1[1];
												$email=$row1[2];
												$feedback=$row1[3];
												$type=$row1[4];
												?>
									
										<tr>
											<td><?php echo $sl; ?></td>
											<td class="d-none d-xl-table-cell"><?php echo $name; ?></td>
											<td class="d-none d-xl-table-cell"><?php echo $email; ?></td>
											<td><?php echo $feedback; ?></td>
											<td><?php echo $type; ?></td>
											<td><a href="feedback.php?dlid=<?php echo $id; ?>" class="btn btn-primary form-control" >Delete</a></td>
										</tr>
										<?php
												}
												}
												?>
										
									</tbody>
								</table>
							</div>
						</div>
						<?php 
								if(isset($_GET['dlid']))
								{
									$dlid=$_GET['dlid'];
									$query3="delete from feedback where id='".$dlid."'";
									if(mysqli_query($con,$query3))
									{
										echo "<script>
											alert('Deleted successfully.');
											</script>";
										echo "<script> location.href='feedback.php'; </script>";
									}
								}
								?>
					</div>

				</div>
			</main>
		</div>
	</div>

	<script src="js/app.js"></script>

</body>

</html>