<?php
session_start();
if(!isset($_SESSION['user']))
{
	echo "<script> location.href='index.php'; </script>";
}

?>
<!DOCTYPE HTML>
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>AdvoWorld</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<meta name="author" content="" />

  <!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Flexslider  -->
	<link rel="stylesheet" href="css/flexslider.css">
	<!-- Flaticons  -->
	<link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		
	<div class="colorlib-loader"></div>
	
	<div id="page">
	<?php include('nav.php'); ?>

	
	
	<main class="content">
				<div class="container-fluid p-0">

					<div class="mb-3">
						<h1 class="h3 d-inline align-middle">All Request</h1>
						
					</div>
					<div class="row">
						<div class="col-12 col-lg-12 col-xxl-12 d-flex">
							<div class="card flex-fill">
								<div class="card-header">

									<h5 class="card-title mb-0">All Request</h5>
								</div>
								<table class="table table-hover my-0">
									<thead>
										<tr>
											<th>Sl.No</th>
											<th>Name</th>
											<th class="d-none d-xl-table-cell">Comment</th>
											<th class="d-none d-xl-table-cell">Delete</th>
										</tr>
									</thead>
									<tbody>
									<?php
											include("config.php");
											$query2 = "select request.id,request.userid,request.lid,request.comment,lawyer.id,lawyer.name,lawyer.email,lawyer.phone,request.status FROM request INNER JOIN lawyer ON request.lid=lawyer.email where request.userid='".$_SESSION['user']."'";
											$result1 = mysqli_query($con,$query2);
											$count1=mysqlI_num_rows($result1);
											if($count1>0)
											{
											$sl=0;
											while($row1 = mysqli_fetch_array($result1))
											{
											$sl+=1;
											$id=$row1[0];
											$userid=$row1[1];
											$lid=$row1[2];
											$comment=$row1[3];
											$lid=$row1[4];
											$name=$row1[5];
											$email=$row1[6];
											$phone=$row1[7];
											$status=$row1[8];
											?>
									
										<tr>
											<td><?php echo $sl; ?></td>
											<td class="d-none d-xl-table-cell"><?php echo $email; ?><br><?php echo $name; ?><br><?php echo $phone; ?>	</td>
											<td><?php echo $comment; ?></td>
											<td>
											<?php if($status=='') { ?>
											<a href="request.php?dlid=<?php echo $id; ?>" class="btn btn-primary" >Delete</a>
											<?php } else {?>
											Approved
											<?php } ?>
											</td>
										</tr>
										<?php
												}
												}
												?>
										
									</tbody>
								</table>
							</div>
						</div>
						<?php 
								if(isset($_GET['dlid']))
								{
									$dlid=$_GET['dlid'];
									$query3="delete from request where id='".$dlid."'";
									if(mysqli_query($con,$query3))
									{
										echo "<script>
											alert('Deleted successfully.');
											</script>";
										echo "<script> location.href='request.php'; </script>";
									}
								}
								?>
					</div>

				</div>
			</main>
	
	<?php include 'footer.php'; ?>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Stellar Parallax -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- Flexslider -->
	<script src="js/jquery.flexslider-min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>

	</body>
</html>

