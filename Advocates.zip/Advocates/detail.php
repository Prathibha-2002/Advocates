<?php
session_start();
if(!isset($_SESSION['user']))
{
	echo "<script> location.href='index.php'; </script>";
}
?>
<!DOCTYPE HTML>
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>AdvoWorld</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<meta name="author" content="" />

  <!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Flexslider  -->
	<link rel="stylesheet" href="css/flexslider.css">
	<!-- Flaticons  -->
	<link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		
	<div class="colorlib-loader"></div>
	
	<div id="page">
	<?php include('nav.php'); ?>


	<div id="colorlib-blog">
		<div class="container">
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center colorlib-heading">
					<h2>Detailed Info</h2>
					<p>Lawyer Details</p>
				</div>
			</div>
			<?php
			if(isset($_GET['id']))
			{
				$id=$_GET['id'];
			}
			include("config.php");
			$query2 = "select * from lawyer where id='".$id."'";
			$result1 = mysqli_query($con,$query2);
			$count1=mysqlI_num_rows($result1);

			if($count1>0)
			{
			$sl=0;
			while($row1 = mysqli_fetch_array($result1))
			{
			$id=$row1[0];
			$name=$row1[1];
			$type=$row1[2];
			$phone=$row1[3];
			$email=$row1[4];
			$password=$row1[5];
			$image=$row1[6];
			$firm=$row1[7];
			$info=$row1[8];
			$personal=$row1[9];
			$family=$row1[10];
			$immigration=$row1[11];
			$criminal=$row1[12];
			$tax=$row1[13];
			$total=$row1[14];
			$success=$row1[15];
			$addr=$row1[16];
			$city=$row1[17];
			}}
			?>
			
			<div class="row">
				<div class="col-md-6">
					<div class="blog-featured animate-box">
						<a><img class="img-responsive" src="advocate/profile/<?php echo $image; ?>" style="width:600px;height:500px;"></a>
						<h2><a><?php echo $name; ?></a></h2>
						<p class="meta"><span><?php echo $type; ?></span> | <span><?php echo $phone; ?></span> | <span><?php echo $email; ?></span></p>
						<p class="meta"><b>Lawyer Type:</b><span><?php echo $personal; ?></span> | <span><?php echo $family; ?></span> | <span><?php echo $immigration; ?></span>| <span><?php echo $criminal; ?></span>| <span><?php echo $tax; ?></span></p>
						<p><b>Total Number Of Cases: </b><?php echo $total; ?></p>
						<p><b>Successfull Cases: </b><?php echo $success; ?></p>
						<p style="color:blue;"><?php echo $info; ?></p>
						<p><b>Address: </b><?php echo $addr; ?><br><?php echo $city; ?></p>
						<form action="#" method="post">
						<p>
						<div class="col-md-8">
						<label for="fname">Enter Comment</label>
						<input type="text" name="cmt" class="form-control"  required placeholder="Comment"><br>
						<input type="text" name="id1[]" value="<?php echo $email; ?>" hidden="true">
						<button name="submit" type="submit" class="btn btn-primary">Request<i class="icon-arrow-right"></i></button>
						</div>
						</p>
						</form>
										 <?php
	if(isset($_POST['submit']))
	{
		foreach ($_POST['id1'] as $key => $value) 
			{	
				$id1=$value;	
			}
			$cmt=$_POST['cmt'];
		$query = "insert into request(userid,lid,comment) values('".$_SESSION['user']."','".$id1."','".$cmt."')";
		mysqli_query($con,$query) or die(mysqli_error($con));
		echo "<script>
			alert('Request Added');
			</script>";
		echo "<script> location.href='home.php'; </script>";
		
	}
?>
						
						
					</div>
				</div>
				<div class="col-md-6">
					<div class="row">
			<?php
			include("config.php");
			$query2 = "select * from jrlawyer where lid='".$email."'";
			$result1 = mysqli_query($con,$query2);
			$count1=mysqlI_num_rows($result1);
			if($count1>0)
			{
			$sl=0;
			while($row1 = mysqli_fetch_array($result1))
			{
			$id=$row1[0];
			$name=$row1[1];
			$cases=$row1[2];
			$image=$row1[3];
			$experi=$row1[4];
			?>
					
						<div class="col-md-12 animate-box">
							<div class="blog-entry">
								<a href="blog.html" class="thumb"><img class="img-responsive" src="advocate/lawyers/<?php echo $image; ?>" alt=""></a>
								<div class="desc">
									<h3><a href="blog.html"><?php echo $name; ?></a></h3>
									<p class="meta"><span>No. Cases :<?php echo $cases; ?></span> | <span>Experience: <?php echo $experi; ?></span></p>
								</div>
							</div>
						</div>

						<?php
			}
			}
			?>

					</div>
				</div>
			</div>
		</div>
	</div>

	
	<?php include 'footer.php'; ?>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Stellar Parallax -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- Flexslider -->
	<script src="js/jquery.flexslider-min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>

	</body>
</html>

