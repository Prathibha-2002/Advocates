<?php
session_start();
if(!isset($_SESSION['user']))
{
	echo "<script> location.href='index.php'; </script>";
}

?>
<!DOCTYPE HTML>
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>AdvoWorld</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<meta name="author" content="" />

  <!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Flexslider  -->
	<link rel="stylesheet" href="css/flexslider.css">
	<!-- Flaticons  -->
	<link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		
	<div class="colorlib-loader"></div>
	
	<div id="page">
	<?php include('nav.php'); ?>

	
	
	
	<div id="colorlib-contact">
		<div class="container">
			<div class="row">
				<div class="col-md-5 col-md-push-1 animate-box">
					
					<div class="colorlib-contact-info">
						<h3>User Information</h3>
						<?php
			include("config.php");
				$query2 = "select * from user where email='".$_SESSION['user']."'";
				$result1 = mysqli_query($con,$query2);
				$count1=mysqlI_num_rows($result1);

				if($count1>0)
				{
				$sl=0;
				while($row1 = mysqli_fetch_array($result1))
				{
				$id=$row1[0];
				$name=$row1[1];
				$email=$row1[2];
				$phone=$row1[3];
				$password=$row1[4];
				}
				}
				?>
						<ul>
							<li class="address"><?php echo $name; ?></li>
							<li class="phone"><?php echo $phone; ?></li>
							<li class="email"><?php echo $email; ?></li>
							<li class="url"><?php echo $password; ?></li>
						</ul>
					</div>

				</div>
				<div class="col-md-6 animate-box">
					<h3>UPDATE : </h3>
					<form action="#" method="post">
						<div class="row form-group">
							<div class="col-md-6">
								<!-- <label for="fname">First Name</label> -->
								<input type="text" name="name" class="form-control" value="<?php echo $name; ?>" required placeholder="User Name"  pattern="[a-zA-Z]+" title="Letters only" required>
							</div>
							<div class="col-md-6">
								<!-- <label for="fname">First Name</label> -->
								<input type="text" name="email" class="form-control" value="<?php echo $email; ?>" required placeholder="Your email address" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" title="xyz@something.com" required>
							</div>
						</div>
						<div class="row form-group">
							<div class="col-md-6">
								<!-- <label for="fname">First Name</label> -->
								<input type="text" name="phone" class="form-control" value="<?php echo $phone; ?>" required placeholder="User Phone Number" pattern="^\d{10}$" title="10 numeric characters only" required>
							</div>
							<div class="col-md-6">
								<!-- <label for="fname">First Name</label> -->
								<input type="text" name="password" class="form-control" value="<?php echo $password; ?>" required placeholder="Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="At least one number and one uppercase and lowercase letter,and at least 8 or more characters" required>
							</div>
						</div>

						
						<div class="form-group">
							<input type="submit" name="submit" value="UPDATE" class="btn btn-primary">
						</div>

					</form>	
					 <?php
if(isset($_POST['submit']))
{
	error_reporting(1);
	include("config.php");
	
	$name=$_POST['name'];
	$phone=$_POST['phone'];
	$password=$_POST['password'];

		$query1= "update user set name='".$name."', phone='".$phone."', password='".$password."' where email='".$_SESSION['user']."'";
			   
			if(mysqli_query($con,$query1))
			{
				echo "<script>
					alert('Update Successfully...');
					</script>";
				echo "<script> location.href='myprofile.php'; </script>";
			}
		
		
}
?>
				</div>
			</div>
			
		</div>
	</div>
	
	<?php include 'footer.php'; ?>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Stellar Parallax -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- Flexslider -->
	<script src="js/jquery.flexslider-min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>

	</body>
</html>

