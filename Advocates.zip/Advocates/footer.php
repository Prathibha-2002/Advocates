	<footer id="colorlib-footer" role="contentinfo">
		<div class="container">
			<div class="row row-pb-md">
				<div class="col-md-3 colorlib-widget">
					<h4>Advo World</h4>
					<p>Established in 2002, Advo World Mangalore has been one of the leading legal practitioners and advisors in the Mangalore region and neighboring communities for over a couple of decades.</p>
				</div>
				<div class="col-md-3 col-md-push-1">
					<h4>Navigation</h4>
					<ul class="colorlib-footer-links">
						<li><a href="home.php">Home</a></li>
						<li><a href="practice.html">My Requests</a></li>
						<li><a href="about.php">About</a></li>
						<li><a href="contact.php">Contact</a></li>
						<li><a href="myprofile.php">Profile</a></li>
						<li><a href="logout.php">Logout</a></li>
						<li class="btn-cta"><a href="location.php"><span>Find Lawyer</span></a></li>
					</ul>
				</div>

				<div class="col-md-3 col-md-push-1">
					<h4>Contact Information</h4>
					<ul class="colorlib-footer-links">
						<li>2nd Floor Prime Tower, Bendoorwell, Bendoor, <br>Mangalore, Karnataka 575002</li>
						<li><a href="tel://9482439704">+91-94824-39704</a></li>
						<li><a href="mailto:advoworld@info.com">advoworld@info.com</a></li>
					</ul>
				</div>

				<div class="col-md-3 col-md-push-1">
					<h4>Opening Hours</h4>
					<ul class="colorlib-footer-links">
						<li>Mon - Thu: 9:00AM - 6:00PM</li>
						<li>Fri 8:00AM - 6:30PM</li>
						<li>Sat 9:30AM - 4:00PM</li>
					</ul>
				</div>

			</div>

			<div class="row copyright">
				<div class="col-md-12 text-center">
					<p>
					<small class="block">&copy; 2018 Advo World. All Rights Reserved. Created by <a href="" target="_blank">SDM</a></small> 
					<small class="block">Distributed by: <a href="" target="_blank">Mangalore</a></small>
					</p>
					<p>
						<ul class="colorlib-social-icons">
							<li><a href="#"><i class="icon-twitter"></i></a></li>
							<li><a href="#"><i class="icon-facebook"></i></a></li>
							<li><a href="#"><i class="icon-linkedin"></i></a></li>
							<li><a href="#"><i class="icon-dribbble"></i></a></li>
						</ul>
					</p>
				</div>
			</div>

		</div>
	</footer>