<?php
session_start();
if(!isset($_SESSION['user']))
{
	echo "<script> location.href='index.php'; </script>";
}
if(isset($_GET['type']))
{
	$_SESSION['type']=$_GET['type'];
}
?>
<!DOCTYPE HTML>
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>AdvoWorld</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<meta name="author" content="" />

  <!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Flexslider  -->
	<link rel="stylesheet" href="css/flexslider.css">
	<!-- Flaticons  -->
	<link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		
	<div class="colorlib-loader"></div>
	
	<div id="page">
	<?php include('nav.php'); ?>

	
	
	<div id="colorlib-blog">
		<div class="container">
			<div class="row">
			<?php
			include("config.php");
			$query2 = "select * from lawyer where (city='".$_SESSION['city']."' and type='".$_SESSION['type']."') and (personal='".$_SESSION['area']."' or family='".$_SESSION['area']."' or immigration='".$_SESSION['area']."' or criminal='".$_SESSION['area']."' or tax='".$_SESSION['area']."')";
												$result1 = mysqli_query($con,$query2);
												$count1=mysqlI_num_rows($result1);

												if($count1>0)
												{
												$sl=0;
												while($row1 = mysqli_fetch_array($result1))
												{
												$id=$row1[0];
												$name=$row1[1];
												$type=$row1[2];
												$phone=$row1[3];
												$email=$row1[4];
												$password=$row1[5];
												$image=$row1[6];
												$firm=$row1[7];
												$info=$row1[8];
												$personal=$row1[9];
												$family=$row1[10];
												$immigration=$row1[11];
												$criminal=$row1[12];
												$tax=$row1[13];
												$total=$row1[14];
												$success=$row1[15];
												$addr=$row1[16];
												$city=$row1[17];
												?>
												
				<div class="col-lg-4 col-md-4">
					<div class="colorlib-blog animate-box">
						<a href="#"><img class="img-responsive" src="advocate/profile/<?php echo $image; ?>" alt=""></a>
						<div class="blog-text">
						<?php if($type=='Law Firm')
						{
							?>
							<h3><a href="#"><?php echo $firm; ?></a></h3>
							<?php
						}
						?>
							<h3><a href="#"><?php echo $name; ?></a></h3>
							<p class="meta"><span>Total Cases: <?php echo $total; ?><br>
							Success Rate: <?php echo $success; ?>%</span></p>
							<p>Email: <?php echo $name; ?></p>
							<a href="detail.php?id=<?php echo $id; ?>" class="btn btn-primary">Read More <i class="icon-arrow-right"></i></a>
						</div> 
					</div>
				</div>
				<?php
												}
												}
												?>
				
			</div>
		</div>
	</div>

	
	
	<?php include 'footer.php'; ?>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Stellar Parallax -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- Flexslider -->
	<script src="js/jquery.flexslider-min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>

	</body>
</html>

