<nav class="colorlib-nav" role="navigation">
		<div class="top-menu">
			<div class="container">
				<div class="row">
					<div class="col-md-2">
						<div id="colorlib-logo"><a href="index.html">Advo<span>World.</span></a></div>
					</div>
					<div class="col-md-10 text-right menu-1">
						<ul>
							<li><a href="home.php">Home</a></li>
							<li><a href="request.php">My Requests</a></li>
							<li><a href="about.php">About</a></li>
							<li><a href="contact.php">Contact</a></li>
							<li><a href="myprofile.php">Profile</a></li>
							<li><a href="logout.php">Logout</a></li>
							<li class="btn-cta"><a href="location.php"><span>Find Lawyer</span></a></li>
							<!-- <li class="btn-cta"><a href="#"><span>Sign Up</span></a></li> -->
						</ul>
					</div>
				</div>
				
			</div>
		</div>
	</nav>