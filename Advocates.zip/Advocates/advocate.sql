-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 23, 2022 at 10:06 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `advocate`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`) VALUES
(1, 'admin@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `feedback` varchar(1000) NOT NULL,
  `type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `feedback`, `type`) VALUES
(1, '', 'jack@gmail.com', 'Great Application. ', 'advocate'),
(2, 'Bhavani', 'raj@gmail.com', 'efywgfvhelgfaughb iur bjbiuwi hjwriuhebfb dbhd bh', 'user'),
(3, '', 'lokesh@gmail.com', 'hai helooojhdjcbhjbdbzx ', 'advocate');

-- --------------------------------------------------------

--
-- Table structure for table `jrlawyer`
--

CREATE TABLE `jrlawyer` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `cases` int(50) NOT NULL,
  `image` varchar(100) NOT NULL,
  `experience` varchar(100) NOT NULL,
  `lid` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jrlawyer`
--

INSERT INTO `jrlawyer` (`id`, `name`, `cases`, `image`, `experience`, `lid`) VALUES
(1, 'Charlie spector', 90, 'Charlie spectorface9.jpg', '10', 'jack@gmail.com'),
(5, 'Alan K', 25, 'Alanface13.jpg', '5', 'jack@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `lawyer`
--

CREATE TABLE `lawyer` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `image` varchar(100) NOT NULL,
  `firm` varchar(50) NOT NULL,
  `info` varchar(1000) NOT NULL,
  `personal` varchar(50) NOT NULL,
  `family` varchar(50) NOT NULL,
  `immigration` varchar(50) NOT NULL,
  `criminal` varchar(50) NOT NULL,
  `tax` varchar(50) NOT NULL,
  `total` int(50) NOT NULL,
  `success` int(50) NOT NULL,
  `addr` varchar(1000) NOT NULL,
  `city` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lawyer`
--

INSERT INTO `lawyer` (`id`, `name`, `type`, `phone`, `email`, `password`, `image`, `firm`, `info`, `personal`, `family`, `immigration`, `criminal`, `tax`, `total`, `success`, `addr`, `city`) VALUES
(1, 'Jack john', 'Law Firm', '7019356629', 'jack@gmail.com', '123', 'Pearson Associatesface13.jpg', 'Pearson Associates', 'Consectetur adipisicing elitConsectetur adipisicing elitConsectetur adipisicing elitConsectetur adipisicing elitConsectetur adipisicing elitConsectetur adipisicing elitConsectetur adipisicing elitConsectetur adipisicing elitConsectetur adipisicing elit', '', '', '', 'criminal', 'tax', 200, 84, 'AXY Building, MG ROAD, Mangalore 575005', 'Mangalore'),
(2, 'Lokesh', 'Individual', '9345635464', 'lokesh@gmail.com', '123', 'face9.jpg', '', 'empower communities thought empower communities thought empower communities thought empower communities thought empower communities thought empower communities thought empower communities thought empower communities thought ', 'personal', 'family', 'immigration', 'criminal', 'tax', 100, 90, 'Mangalore 575005', 'Mangalore');

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `id` int(100) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `lid` varchar(100) NOT NULL,
  `comment` varchar(1000) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`id`, `userid`, `lid`, `comment`, `status`) VALUES
(1, 'raj@gmail.com', 'jack@gmail.com', 'sedfgrty', 'Approve'),
(2, 'raj@gmail.com', 'jack@gmail.com', 'scc', '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `phone`, `password`) VALUES
(1, 'Rajeshaa', 'raj@gmail.com', '8551245213', '123567');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jrlawyer`
--
ALTER TABLE `jrlawyer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lawyer`
--
ALTER TABLE `lawyer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `jrlawyer`
--
ALTER TABLE `jrlawyer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `lawyer`
--
ALTER TABLE `lawyer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
